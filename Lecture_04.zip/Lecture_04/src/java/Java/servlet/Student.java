/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Java.servlet;

/**
 *
 * @author apcl
 */
public class Student {
    private String name;
    private String subject;
    private String round;

    public Student() {
    }

    public Student(String name, String subject, String round) {
        this.name = name;
        this.subject = subject;
        this.round = round;
    }

    public String getRound() {
        return round;
    }

    public void setRound(String round) {
        this.round = round;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }
    
}
